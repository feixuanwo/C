#include <stdio.h>

void welcome()
{
	printf("Welcome to Beijing!\n");
}


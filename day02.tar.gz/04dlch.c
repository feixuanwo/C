#include <stdio.h>
void welcome()
{
	printf("北京欢迎你\n");
}


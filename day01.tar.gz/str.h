#ifndef CZQ_STR
#define CZQ_STR

void strtoupper(char*);
void strtolower(char*);
void i2str(int, char*);
extern double gvar;

#endif


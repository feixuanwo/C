#include <stdio.h>

void welcome(const char* name)
{
//	printf("Welcome to tarena, %s!\n", name);
	printf("达内欢迎你, %s!\n", name);
}


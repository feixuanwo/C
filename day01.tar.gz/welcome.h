#ifndef CZQ_WELCOME
#define CZQ_WELCOME

void welcome(const char*);

#endif


#include <stdio.h>

int main()
{
	puts("hello, csd1212!");
}

